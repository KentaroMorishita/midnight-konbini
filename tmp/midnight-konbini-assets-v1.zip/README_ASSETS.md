# Midnight Konbini assets v1

このZIPをリポジトリ直下へ展開してください。

```sh
unzip midnight-konbini-assets-v1.zip
git add public/sprites assets/manifest.json
git commit -m "feat: add production sprite assets"
git push
```

含まれる実装用PNG:

- `public/sprites/characters/clerk_male_sheet.png` — 144x384, 48x96/frame, 3x4
- `public/sprites/fixtures/shelf_snack.png` — 144x48

画像はこの会話で確認できた正常な元PNGをそのまま収録しています。
