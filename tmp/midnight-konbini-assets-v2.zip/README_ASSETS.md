# Midnight Konbini Assets v2 Candidate Bundle

スマホから `tmp/` に ZIP を 1 個アップするためのバンドルです。

## Verified
- `public/sprites/characters/clerk_male_sheet.png`
- `public/sprites/fixtures/shelf_snack.png`

## Fixture candidates
個別透過 PNG として切り出せた候補をまとめています。
この v2 では **絵の再加工・サイズ正規化をしていません**。
まず GitHub / 実画面で見た目を確認して、OK のものだけ final grid size に固定します。

`docs/previews/fixtures-contact-sheet.png` は確認用です。
