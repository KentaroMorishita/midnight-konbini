# Midnight Konbini Assets v3

Character sheet bundle.

- 3 columns x 4 rows
- 144x384 px per sheet
- 48x96 px per frame
- row order: down / left / right / up
- frame order: idle / walk_1 / walk_2

The four new generated sheets were normalized only by resizing the entire
RGBA sheet from 768x2048 to 144x384. No crop, repaint, frame rearrangement,
or background replacement was applied.

`clerk_male_sheet.png` is the previously verified asset.
The other four sheets are candidates for visual review.
